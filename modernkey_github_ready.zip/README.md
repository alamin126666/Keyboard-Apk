# ModernKeyboard ⌨️

A modern Android keyboard app built with Kotlin & Jetpack Compose.

## ✨ Features
- 🔤 15+ Unicode font styles
- 🎙️ Voice-to-text typing
- 😀 3,600+ Emojis with search
- 🎨 Light & Dark themes
- 📋 Clipboard manager

## 🏗️ Build

### Via GitHub Actions (Recommended)
Push to `main` branch → GitHub Actions auto-builds APK
→ Go to **Actions** tab → Download artifact `ModernKeyboard-Debug-APK`

### Local Build
```bash
# Requires Android Studio or JDK 17 + Android SDK
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/
```

## 📋 Requirements
- Android 7.0+ (API 24+)
- Kotlin 2.2.10
- Jetpack Compose

## 🚀 Install as Keyboard
1. Install APK on your phone
2. Settings → General Management → Keyboard → Add keyboard → ModernKeyboard
3. Set as default keyboard
