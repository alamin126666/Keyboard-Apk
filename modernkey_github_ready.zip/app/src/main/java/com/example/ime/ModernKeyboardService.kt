package com.example.ime

import android.inputmethodservice.InputMethodService
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.voice.VoiceInputManager
import androidx.compose.runtime.*
import com.example.ui.keyboard.KeyboardScreen

class ModernKeyboardService : InputMethodService(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    private lateinit var voiceInputManager: VoiceInputManager
    private var isRecording = mutableStateOf(false)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        voiceInputManager = VoiceInputManager(this)
    }

    override fun onCreateInputView(): View {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        
        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@ModernKeyboardService)
            setViewTreeViewModelStoreOwner(this@ModernKeyboardService)
            setViewTreeSavedStateRegistryOwner(this@ModernKeyboardService)
            setContent {
                com.example.ui.theme.MyApplicationTheme {
                    val isRecordingState by isRecording
                    KeyboardScreen(
                        onKeyPress = { handleKeyPress(it) },
                        onAction = { handleAction(it) },
                        isRecording = isRecordingState
                    )
                }
            }
        }
        return composeView
    }
    
    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
    }

    override fun onDestroy() {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        voiceInputManager.stopListening()
        store.clear()
        super.onDestroy()
    }

    private fun handleKeyPress(text: String) {
        val inputConnection = currentInputConnection ?: return
        inputConnection.commitText(text, 1)
    }

    private fun handleAction(action: KeyboardAction) {
        val inputConnection = currentInputConnection ?: return
        when (action) {
            KeyboardAction.DELETE -> {
                inputConnection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
                inputConnection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL))
            }
            KeyboardAction.ENTER -> {
                val imeOptions = currentInputEditorInfo?.imeOptions ?: 0
                val actionId = imeOptions and EditorInfo.IME_MASK_ACTION
                when (actionId) {
                    EditorInfo.IME_ACTION_SEARCH,
                    EditorInfo.IME_ACTION_SEND,
                    EditorInfo.IME_ACTION_GO,
                    EditorInfo.IME_ACTION_DONE -> {
                        inputConnection.performEditorAction(actionId)
                    }
                    else -> {
                        inputConnection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                        inputConnection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                    }
                }
            }
            KeyboardAction.SPACE -> {
                inputConnection.commitText(" ", 1)
            }
            KeyboardAction.VOICE -> {
                if (isRecording.value) {
                    voiceInputManager.stopListening()
                    isRecording.value = false
                } else {
                    isRecording.value = true
                    voiceInputManager.startListening(
                        onResult = { text ->
                            isRecording.value = false
                            currentInputConnection?.commitText("$text ", 1)
                        },
                        onError = {
                            isRecording.value = false
                        }
                    )
                }
            }
        }
    }
}

enum class KeyboardAction {
    DELETE,
    ENTER,
    SPACE,
    VOICE
}
