package com.example.ui.keyboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.font.FontConverter
import com.example.font.FontStyle
import com.example.ime.KeyboardAction

@Composable
fun KeyboardScreen(
    onKeyPress: (String) -> Unit,
    onAction: (KeyboardAction) -> Unit,
    isRecording: Boolean = false
) {
    var isShifted by remember { mutableStateOf(false) }
    var currentFont by remember { mutableStateOf(FontStyle.NORMAL) }
    var showEmojiPanel by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp))
            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.95f))
            .padding(top = 16.dp, bottom = 8.dp, start = 8.dp, end = 8.dp)
    ) {
        if (showEmojiPanel) {
            // Simplified Emoji Panel
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                   modifier = Modifier.fillMaxWidth().padding(8.dp),
                   horizontalArrangement = Arrangement.SpaceBetween,
                   verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Emojis", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    IconButton(onClick = { showEmojiPanel = false }) {
                        Text("✖️", color = MaterialTheme.colorScheme.onSurface)
                    }
                }
                
                val basicEmojis = listOf("😀", "😂", "🥰", "😎", "🤔", "🥺", "😭", "👍", "🙏", "🔥", "❤️", "✨")
                Row(modifier = Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    basicEmojis.take(6).forEach { emoji ->
                        Text(text = emoji, fontSize = 24.sp, modifier = Modifier.clickable { onKeyPress(emoji) }.padding(8.dp))
                    }
                }
                Row(modifier = Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    basicEmojis.drop(6).take(6).forEach { emoji ->
                        Text(text = emoji, fontSize = 24.sp, modifier = Modifier.clickable { onKeyPress(emoji) }.padding(8.dp))
                    }
                }
                
                Spacer(modifier = Modifier.weight(1f))
                
                KeyButton(
                    text = "⌫",
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                    onClick = { onAction(KeyboardAction.DELETE) },
                    backgroundColor = Color(0xFFBDBDBD)
                )
            }
        } else {
            // Font Bar
            LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 4.dp)
        ) {
            items(FontStyle.values()) { style ->
                val isSelected = style == currentFont
                Surface(
                    modifier = Modifier.padding(vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp),
                    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                    contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                             else androidx.compose.foundation.BorderStroke(1.dp, Color.Transparent),
                    shadowElevation = if (isSelected) 0.dp else 1.dp,
                    onClick = { currentFont = style }
                ) {
                    Box(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        val previewText = FontConverter.convert("Aa", style)
                        Text(
                            text = "$previewText ${style.displayName}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        val keys = listOf(
            listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
            listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
            listOf("z", "x", "c", "v", "b", "n", "m")
        )

        keys.forEachIndexed { rowIndex, row ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                if (rowIndex == 2) {
                    KeyButton(
                        text = "⇧",
                        modifier = Modifier.weight(1.5f),
                        onClick = { isShifted = !isShifted },
                        backgroundColor = if (isShifted) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant,
                        textColor = MaterialTheme.colorScheme.onSurface
                    )
                }

                row.forEach { key ->
                    val rawText = if (isShifted) key.uppercase() else key
                    val convertedText = FontConverter.convert(rawText, currentFont)
                    KeyButton(
                        text = convertedText,
                        modifier = Modifier.weight(1f),
                        onClick = { onKeyPress(convertedText) },
                        backgroundColor = MaterialTheme.colorScheme.surface,
                        textColor = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (rowIndex == 2) {
                    KeyButton(
                        text = "⌫",
                        modifier = Modifier.weight(1.5f),
                        onClick = { onAction(KeyboardAction.DELETE) },
                        backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
                        textColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Bottom row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            KeyButton(text = "😀", modifier = Modifier.weight(1.5f), onClick = { showEmojiPanel = true }, backgroundColor = MaterialTheme.colorScheme.surfaceVariant, textColor = MaterialTheme.colorScheme.onSurfaceVariant)
            KeyButton(
                text = if (isRecording) "🔴" else "🎙️", 
                modifier = Modifier.weight(1.5f), 
                onClick = { onAction(KeyboardAction.VOICE) }, 
                backgroundColor = if (isRecording) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant
            )
            KeyButton(text = "Space", modifier = Modifier.weight(4f), onClick = { onAction(KeyboardAction.SPACE) }, backgroundColor = MaterialTheme.colorScheme.surface, textColor = MaterialTheme.colorScheme.onSurface)
            KeyButton(text = ".", modifier = Modifier.weight(1f), onClick = { onKeyPress(".") }, backgroundColor = MaterialTheme.colorScheme.surface, textColor = MaterialTheme.colorScheme.onSurface)
            KeyButton(text = "↵", modifier = Modifier.weight(1.5f), onClick = { onAction(KeyboardAction.ENTER) }, backgroundColor = MaterialTheme.colorScheme.primary, textColor = MaterialTheme.colorScheme.onPrimary)
        }
        } // End of else block
    }
}

@Composable
fun KeyButton(
    text: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    backgroundColor: Color = Color.White,
    textColor: Color = Color.Black
) {
    Surface(
        modifier = modifier
            .padding(horizontal = 3.dp)
            .height(48.dp),
        shape = RoundedCornerShape(8.dp),
        color = backgroundColor,
        shadowElevation = 1.dp,
        onClick = onClick
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            Text(
                text = text,
                color = textColor,
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )
        }
    }
}
