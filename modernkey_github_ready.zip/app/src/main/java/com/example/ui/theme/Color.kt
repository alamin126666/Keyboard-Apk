package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Indigo500 = Color(0xFF6366F1)
val Indigo600 = Color(0xFF4F46E5)
val Indigo100 = Color(0xFFE0E7FF)
val Indigo700 = Color(0xFF4338CA)

val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate300 = Color(0xFFCBD5E1)
val Slate400 = Color(0xFF94A3B8)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)

