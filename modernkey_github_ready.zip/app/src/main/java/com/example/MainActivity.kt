package com.example

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
          Column(
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding)
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
          ) {
            Text(
              text = "ModernKey",
              style = MaterialTheme.typography.displaySmall
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "Setup your new stylish keyboard.",
              style = MaterialTheme.typography.bodyLarge
            )
            
            Spacer(modifier = Modifier.height(48.dp))
            
            Button(
              onClick = {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
              },
              modifier = Modifier.fillMaxWidth()
            ) {
              Text("1. Enable Keyboard in Settings")
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            var text by remember { mutableStateOf("") }
            OutlinedTextField(
              value = text,
              onValueChange = { text = it },
              label = { Text("Test ModernKey Here") },
              modifier = Modifier.fillMaxWidth(),
              minLines = 3
            )
          }
        }
      }
    }
  }
}
