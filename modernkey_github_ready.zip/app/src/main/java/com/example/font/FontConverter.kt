package com.example.font

enum class FontStyle(val displayName: String) {
    NORMAL("Normal"),
    BOLD_SERIF("Bold"),
    ITALIC("Italic"),
    BOLD_ITALIC("Bold Italic"),
    SCRIPT("Script"),
    BOLD_SCRIPT("B-Script"),
    FRAKTUR("Fraktur"),
    DOUBLE_STRUCK("Double"),
    MONOSPACE("Mono"),
    CIRCLED("Circled"),
    SQUARED("Squared"),
    TINY_CAPS("Tiny Caps"),
    UPSIDE_DOWN("Upside Down"),
    STRIKETHROUGH("Strike"),
    UNDERLINE("Underline")
}

object FontConverter {
    fun convert(text: String, style: FontStyle): String {
        if (style == FontStyle.NORMAL) return text
        
        if (style == FontStyle.STRIKETHROUGH) {
            return text.map { it + "\u0336" }.joinToString("")
        }
        if (style == FontStyle.UNDERLINE) {
            return text.map { it + "\u0332" }.joinToString("")
        }
        
        return text.map { char ->
            val index = when {
                char in 'A'..'Z' -> char - 'A'
                char in 'a'..'z' -> char - 'a' + 26
                char in '0'..'9' -> char - '0' + 52
                else -> -1
            }
            
            if (index != -1 && style.ordinal - 1 < fontMaps.size) {
                val map = fontMaps[style.ordinal - 1]
                if (index < map.length) {
                    val replaced = map.codePointAt(map.offsetByCodePoints(0, index))
                    String(Character.toChars(replaced))
                } else char.toString()
            } else {
                char.toString()
            }
        }.joinToString("")
    }

    // Maps containing A-Z, a-z, 0-9 for each style
    private val fontMaps = listOf(
        // BOLD_SERIF
        "𝐀𝐁𝐂𝐃𝐄𝐅𝐆𝐇𝐈𝐉𝐊𝐋𝐌𝐍𝐎𝐏𝐐𝐑𝐒𝐓𝐔𝐕𝐖𝐗𝐘𝐙𝐚𝐛𝐜𝐝𝐞𝐟𝐠𝐡𝐢𝐣𝐤𝐥𝐦𝐧𝐨𝐩𝐪𝐫𝐬𝐭𝐮𝐯𝐰𝐱𝐲𝐳𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟗𝟖𝟗",
        // ITALIC
        "𝐴𝐵𝐶𝐷𝐸𝐹𝐺𝐻𝐼𝐽𝐾𝐿𝑀𝑁𝑂𝑃𝑄𝑅𝑆𝑇𝑈𝑉𝑊𝑋𝑌𝑍𝑎𝑏𝑐𝑑𝑒𝑓𝑔ℎ𝑖𝑗𝑘𝑙𝑚𝑛𝑜𝑝𝑞𝑟𝑠𝑡𝑢𝑣𝑤𝑥𝑦𝑧0123456789",
        // BOLD_ITALIC
        "𝑨𝑩𝑪𝑫𝑬𝑭𝑮𝑯𝑰𝑱𝑲𝑳𝑴𝑵𝑶𝑷𝑸𝑹𝑺𝑻𝑼𝑽𝑾𝑿𝒀𝒁𝒂𝒃𝒄𝒅𝒆𝒇𝒈𝒉𝒊𝒋𝒌𝒍𝒎𝒏𝒐𝒑𝒒𝒓𝒔𝒕𝒖𝒗𝒘𝒙𝒚𝒛𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟗𝟖𝟗",
        // SCRIPT
        "𝒜ℬ𝒞𝒟ℰℱ𝒢ℋℐ𝒥𝒦ℒℳ𝒩𝒪𝒫𝒬ℛ𝒮𝒯𝒰𝒱𝒲𝒳𝒴𝒵𝒶𝒷𝒸𝒹ℯ𝒻ℊ𝒽𝒾𝒿𝓀𝓁𝓂𝓃ℴ𝓅𝓆𝓇𝓈𝓉𝓊𝓋𝓌𝓍𝓎𝓏0123456789",
        // BOLD_SCRIPT
        "𝓐𝓑𝓒𝓓𝓔𝓕𝓖𝓗𝓘𝓙𝓚𝓛𝓜𝓝𝓞𝓟𝓠𝓡𝓢𝓣𝓤𝓥𝓦𝓧𝓨𝓩𝓪𝓫𝓬𝓭𝓮𝓯𝓰𝓱𝓲𝓳𝓴𝓵𝓶𝓷𝓸𝓹𝓺𝓻𝓼𝓽𝓾𝓿𝔀𝔁𝔂𝔃𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗",
        // FRAKTUR
        "𝔄𝔅ℭ𝔇𝔈𝔉𝔊ℌℑ𝔍𝔎𝔏𝔐𝔑𝔒𝔓𝔔ℜ𝔖𝔗𝔘𝔙𝔚𝔛𝔜ℨ𝔞𝔟𝔠𝔡𝔢𝔣𝔤𝔥𝔦𝔧𝔨𝔩𝔪𝔫𝔬𝔭𝔮𝔯𝔰𝔱𝔲𝔳𝔴𝔵𝔶𝔷0123456789",
        // DOUBLE_STRUCK
        "𝔸𝔹ℂ𝔻𝔼𝔽𝔾ℍ𝕀𝕁𝕂𝕃𝕄ℕ𝕆ℙℚℝ𝕊𝕋𝕌𝕍𝕎𝕏𝕐ℤ𝕒𝕓𝕔𝕕𝕖𝕗𝕘𝕙𝕚𝕛𝕜𝕝𝕞𝕟𝕠𝕡𝕢𝕣𝕤𝕥𝕦𝕧𝕨𝕩𝕪𝕫𝟘𝟙𝟚𝟛𝟟𝟝𝟞𝟟𝟠𝟡",
        // MONOSPACE
        "𝙰𝙱𝙲𝙳𝙴𝙵𝙶𝙷𝙸𝙹𝙺𝙻𝙼𝙽𝙾𝙿𝚀𝚁𝚂𝚃𝚄𝚅𝚆𝚇𝚈𝚉𝚊𝚋𝚌𝚍𝚎𝚏𝚐𝚑𝚒𝚓𝚔𝚕𝚖𝚗𝚘𝚙𝚚𝚛𝚜𝚝𝚞𝚟𝚠𝚡𝚢𝚣𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿",
        // CIRCLED
        "ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ⓪①②③④⑤⑥⑦⑧⑨",
        // SQUARED
        "🄰🄱🄲🄳🄴🄵🄶🄷🄸🄹🄺🄻🄼🄽🄾🄿🅀🅁🅂🅃🅄🅅🅆🅇🅈🅉🄰🄱🄲🄳🄴🄵🄶🄷🄸🄹🄺🄻🄼🄽🄾🄿🅀🅁🅂🅃🅄🅅🅆🅇🅈🅉0123456789", // lower same as upper
        // TINY_CAPS
        "ABCDEFGHIJKLMNOPQRSTUVWXYZᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ0123456789",
        // UPSIDE_DOWN
        "∀𐐒ƆᗡƎℲ⅁HIſʞ˥WNOԀΌᴚS⊥∩ΛMXXZɐqɔpǝɟƃɥᴉɾʞlɯuodbɹsʇnʌʍxʎz0ᏓᄅƐㄣ59ㄥ86",
        // STRIKETHROUGH (needs combiners) -> We will handle this specially below
        "",
        // UNDERLINE (needs combiners) -> We will handle this specially below
        ""
    )
}
